"""
URL configuration for Resource_Managment project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path,include
from .import views
from Resource_Manage_App.views import *

urlpatterns = [
    path('',views.index),
    path('home',views.home),
    path('user_logout',views.user_logout),

    #LOGI AND SIGNUP
    path('signup_page',views.signup_page),
    path('reg',views.reg),
    path('login',views.login),

    path('profile',views.profile),
    path('resources',views.resources),
    
    #Website URLS : 
    path('resource_booking',views.resource_booking),
    path('available',views.available),
    path('available_demo',views.available_demo),
    path('bookform',views.bookform),

    # path('check',views.check),

    #Crud Resource
    path('add_resource',views.add_resource),
    path('edit/<int:bid>',views.edit),
    path('update/<int:bid>',views.update),


    path('delete/<int:bid>',views.delete),

    path('edit_admin/<int:id>',views.edit_admin),
    path('delete_admin/<int:id>',views.delete_admin),

    path('showUsers',views.showUsers),

    path('showMyBook',views.showMyBook),


    path('add',views.add),
    path('alert',views.alert),

    #Admin Panel URLS : 
    path('ahome',views.ahome),
    path('addAdmin',views.addAdmin),    #View Add Admin Form
    path('add_Admin',views.add_Admin),  # Call Function to Add Admin In database 
    path('Admin_profile',views.Admin_profile),
    path('showBook',views.showBook),
    path('show_admin',views.show_admin),
    path('showResource',views.showResource),
    path('delete_resource/<int:rid>',views.delete_resource),
    path('edit_resource/<int:rid>',views.edit_resource),
    path('Aindex',views.Aindex),
    path('Admin_edit/<int:bid>',views.Admin_edit),

    #profile update :
     path('edit1/<int:id>',views.edit1),
    path('update1/<int:id>',views.update1),
    path('delete_profile/<int:id>',views.delete_profile),
]
