from .models import *
from django import forms

class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ["bid","rid","uname","sdate","edate","stime","etime","desc","tot"]
        # fields = "__all__"

class editForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ["bid","rid","uname","sdate","edate","stime","etime","desc","tot"]
        # fields = "__all__"
        widgets = {
            'bid': forms.TextInput(attrs={'readonly':'readonly'}),
        }
    

class signupForm(forms.ModelForm):
    class Meta:
        model = signup
        
        fields = ["user","email","pass1","pass2"]

class editForm1(forms.ModelForm):
    class Meta:
        model = signup
        # fields = ["bid","rid","uname","sdate","edate","stime","etime","desc","tot"]
        # fields = "__all__"
        fields = ["user","email","pass1","pass2"]
        widgets = {
            'id': forms.TextInput(attrs={'readonly':'readonly'}),
        }

class LoginForm(forms.ModelForm):
    class Meta:
        model = signup
        fields = "__all__"

class addForm(forms.ModelForm):
    class Meta:
        model = add_resource
        #fields = ["rid","rname"]
        fields = "__all__"