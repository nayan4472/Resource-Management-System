from django.db import models
from django.utils import timezone

# Create your models here.

class signup(models.Model):
    user = models.CharField(max_length=50)
    email = models.EmailField(max_length=150)
    pass1 = models.CharField(max_length=50)
    pass2 = models.CharField(max_length=50)
    roll = models.IntegerField(default=0)
    class Meta:
        db_table=('Register')

class add_resource(models.Model):
    rid =models.AutoField(primary_key=True)
    rname = models.CharField(max_length=50)
    class Meta:
        db_table=('Add_Resource')
    
    def __str__(self):
        return self.rname

class CalendarEvent(models.Model):
    date = models.DateField()  # Date of the event
    color = models.CharField(max_length=10)  # Color of the event (e.g., 'yellow', 'red', 'green')
    booked = models.BooleanField(default=False)  # Whether the event is booked

    def __str__(self):
        return f"Event on {self.date}"

    class Meta:
        ordering = ['date']

class Book(models.Model):
    bid =models.AutoField(primary_key=True)
    rid = models.ForeignKey(add_resource,db_column='rid',on_delete=models.CASCADE,default=True)
    uname = models.CharField(max_length=50)
    sdate = models.DateField()
    edate = models.DateField()
    stime = models.TimeField()
    etime = models.TimeField()
    desc = models.TextField()
    tot = models.CharField(max_length=10)
    class Meta:
        db_table=('Resource_Book')
    # def __str__(self):
    #     return self.rid.rname 
