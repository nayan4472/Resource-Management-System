from django.shortcuts import render,redirect
from django.http import HttpResponse
from Resource_Manage_App.forms import *
from Resource_Manage_App.models import *
from django.contrib import messages
# from django.http import JsonResponse

from schedule.models import Event
from schedule.periods import Month
from datetime import datetime

# views.py

from django.shortcuts import render
from django.utils import timezone
from calendar import HTMLCalendar
from datetime import datetime, timedelta

from django.http import JsonResponse
from django.http import JsonResponse
from datetime import datetime
# Create your views here.

#Admin Panel Templates :

def ahome(request):
    return render(request,'ahome.html')

def Aindex(request):
    return render(request,'Aindex.html')

def addAdmin(request):
    return render(request,'Add_admin.html')

def bookform(request):
    data = add_resource.objects.all()
    return render(request,'resource_booking.html',{'data':data})

def Admin_profile(request):
    Admin =  request.session['user']
    detail = signup.objects.filter(user=Admin)
    return render(request,'Admin_profile.html',{'detail':detail})

def showResource(request):
    data = add_resource.objects.all()
    return render(request,'Show_resources.html',{'data':data})

def showUsers(request):
    data = signup.objects.all()
    return render(request,'showUsers.html',{'data':data})

def add_Admin(request):
    if request.method == 'POST':
        user = request.POST['user']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        roll = request.POST['roll']

        if pass1!=pass2:
            messages.warning(request,"both password not match")
            return redirect('/')
        else:
            check_user = signup.objects.filter(user=user)
            if check_user:
                messages.warning(request,"Admin Already Exist....!")
                return redirect('/addAdmin')
            check_email = signup.objects.filter(email=email)
            if check_email:
                messages.warning(request,"Email Already Exist....!")
                return redirect('/addAdmin')
            reg = signup(user=user,email=email,pass1=pass1,pass2=pass2,roll=roll)
            reg.save()
            messages.success(request,"Admin Successfully Added....!")
            return redirect('/addAdmin')
    else:
        form = signupForm()
    return render(request,'Add_admin.html',{'form':form})

def Admin_edit(request,bid):
    data = Book.objects.get(bid=bid)
    form = BookForm(request.POST,instance=data)
    if form.is_valid():
        form.save()
        return redirect('/showBook')
    return render(request,"Admin_update_book.html",{'data':data})
    
#SIMPLE PAGES :
def home(request):
    return render(request,'home.html')

def cal(request):
    return render(request,'cal.html')

def profile(request):
    user = request.session['user']
    data = signup.objects.get(user=user)
    return render(request,'profile.html',{'data':data})

def resources(request):
    data = add_resource.objects.all()
    return render(request,'resources.html',{'data':data })

def index(request):
    return render(request,'index.html')

def showMyBook(request):
    uname = request.session['user']
    data = Book.objects.filter(uname=uname)
    if data:
        return render(request,'showMyBook.html',{'data':data })
    else:
        return render(request,'home.html')

# def check(request):
#     rname = request.POST['rname']
#     return render(request,'index.html')

# def resource_booking(request):
#     data = Book.objects.all()
#     return render(request,'resource_booking.html',{'data':data })

def sigh_up(request):
    return render(request,'register.html')

def available_demo(request):
    return render(request,'available_demo.html')

def available(request):
    rid = request.POST['rid']
    no = add_resource.objects.filter(rid=rid)
    data = Book.objects.filter(rid=rid)
    # return HttpResponse(no)
    if not data :
        messages.success(request,"All Booking is Availabe for this Resource....!")
        return redirect('/available_demo',{'no':no})
    else:
        # messages.success(request,"All Booking is Availabe....!")
        events = Book.objects.all()  # You can add filters and ordering as needed

    # Pass the data to the template
        context = {
            'cal': events,  # Assuming you pass the events as 'cal' in your template
             # You can also pass other context variables like current_day, current_year, etc.
        }
        return render(request,'available.html',{'data':data})


#LOGIN AND SIGNUP :
def signup_page(request):
    return render(request,'register.html')

def reg(request):
    if request.method == 'POST':
        user = request.POST['user']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        if pass1!=pass2:
            messages.warning(request,"both password not match")
            return redirect('/signup_page')
        else:
            check_user = signup.objects.filter(user=user)
            if check_user:
                messages.warning(request,"User Already Exist....!")
                return redirect('/signup_page')
            check_email = signup.objects.filter(email=email)
            if check_email:
                messages.warning(request,"Email Already Exist....!")
                return redirect('/signup_page')
            reg = signup(user=user,email=email,pass1=pass1,pass2=pass2)
            reg.save()
            messages.success(request,"You are Register Successfully")
            return redirect('/')
    else:
        form = signupForm()
    return render(request,'register.html',{'form':form})

def login(request):
    if request.method == 'POST':
        uname = request.POST['user']
        pwd = request.POST['pass1']
        roll = 1
        check = signup.objects.filter(user=uname,pass1=pwd)
        roll = signup.objects.filter(user=uname,roll=roll)
        if check :
            if roll :
                request.session['user'] = uname
                return render(request,'Aindex.html')
            else :
                request.session['user'] = uname
                return render(request,'home.html')
        else:
            if uname == 'admin' and pwd == 'admin123':
                request.session['user'] = uname
                return render(request,'Aindex.html')
            else:
                messages.warning(request,"Username OR Password Wrong")
                return redirect('/')
    form = LoginForm(request.POST)
    return render(request,'index.html',{'form':form})
      
def user_logout(request):
            try:
                del request.session['user']
            except:
                return redirect('/login')
            return redirect('/login')  

#RESOURCE BOOKING : 

def resource_booking(request):
    date = request.POST.get('sdate')
    check_date = Book.objects.filter(sdate=date)
    data = add_resource.objects.all()
    if check_date:
        messages.warning(request,"This Day Auditorium Already Booked..!")
        return redirect('/resource_booking')
    else:
        if request.method == 'POST':
            form = BookForm(request.POST)
            if form.is_valid():
                form.save() 
                return redirect('/showMyBook')
        else :
            form = BookForm()
        return render(request,"resource_booking.html",{'form':form,'data':data})

    # date = request.POST['sdate']
    # check_date = Book.objects.filter(sdate=date)
    # dd = Book.objects.all()
    # if check_date:
    #     messages.warning(request,"This Day Auditorium Already Booked..!")
    #     return redirect('/resource_booking')
    # else:
    #     form = BookForm(request.POST)
    #     form.save()
    #     return render(request,'resource_booking.html')

def showBook(request):
    data = Book.objects.all()
    if data :
        return render(request,'show_booking.html',{'data':data})
    else:
        messages.warning(request,"No Booking....!")
        return render(request,'Aindex.html')


#Update profile :
def show_admin(request):
    data = signup.objects.filter(roll=1)
    return render(request,'show_admin.html',{'data':data})


# def edit_profile(request,id):
#     data = signup.objects.get(id=id)
#     form = signupForm(request.POST,instance=data)
#     if form.is_valid():
#         form.save()
#         return redirect('/show_admin')
    
#     return render(request,"update_profile.html",{'data':data})

def edit1(request,id):
    data = signup.objects.get(id=id)
    form = editForm1(instance=data)
    return render(request,"update_profile.html",{'data':data,'form':form})

def update1(request,id):
    # rr = Book.objects.filter(bid=bid)
    data = signup.objects.get(id=id)
    form = editForm1(request.POST,instance=data)
    if form.is_valid():
        form.save()
        return redirect('/profile')
    else:
        return render(request,"update_profile.html",{'data':data})        


def delete_profile(request,id):
    data = signup.objects.get(id=id)
    data.delete()
    return redirect("/")

#Update Booking And Delete :
# def edit(request,bid):
#     data = Book.objects.get(bid=bid)
#     form = BookForm(request.POST,instance=data)
#     if form.is_valid():
#         form.save()
#         return redirect('/showMyBook')
#     else:
#         print('hii')
#     return render(request,"update_book.html",{'data':data})
def edit(request,bid):
    data = Book.objects.get(bid=bid)
    form = editForm(instance=data)
    return render(request,"update_book.html",{'data':data,'form':form})

def update(request,bid):
    # rr = Book.objects.filter(bid=bid)
    data = Book.objects.get(bid=bid)
    form = editForm(request.POST,instance=data)
    if form.is_valid():
        form.save()
        return redirect('/showMyBook')
    else:
        print('hii')
    return render(request,"update_book.html",{'data':data})        


def delete(request,id):
    data = Book.objects.get(bid=bid)
    data.delete()
    return redirect("/showBook")


#Add Resources :
def add(request):
    # if request.method == "POST":
    #     form = addForm(request.POST)
    #     if form.is_valid():
    #         form.save()
    #         messages.success(request,"New Resource Added Successfully..!")
    #         return redirect('/ahome')
    # else :
    #     form =addForm()
    # return render(request,"ahome.html",{'form':form})
    # form = addForm(request.POST)
    # form.save()
    # return redirect('/ahome')
    rname = request.POST['rname']
    check = add_resource.objects.filter(rname=rname)
    if check :
        messages.warning(request,"Auditorium Already Exist....!")
        return redirect('/ahome')
    else:
        form = add_resource(rname=rname)
        form.save()
        messages.success(request,"New Resource Added Successfully..!")
        return redirect('/ahome')

#Alert Message Calling Function :
def alert(request):
    return render(request,"alert.html")

#Edit And Delete Resources : 
def edit_resource(request,rid):
      data = add_resource.objects.get(rid=rid)
      form = addForm(request.POST,instance=data)
      if form.is_valid():
        form.save()
        return redirect('/showResource')
      return render(request,"update_resource.html",{'data':data})

def delete_resource(request,rid):
    data = add_resource.objects.get(rid=rid)
    data.delete()
    return redirect("/showResource")

#Edit And Delete Admin : 
def edit_admin(request,id):
    data = signup.objects.get(id=id)
    form = signupForm(request.POST,instance=data)
    if form.is_valid():
        form.save()
        return redirect('/show_admin')
    else:
        return render(request,"updateAdmin.html",{'data':data})        

def delete_admin(request,id):
    data = signup.objects.get(id=id)
    data.delete()
    messages.success(request,"Delete Admin Successfully..!")
    return redirect("/show_admin")