from django.apps import AppConfig


class ResourceManageAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Resource_Manage_App'
